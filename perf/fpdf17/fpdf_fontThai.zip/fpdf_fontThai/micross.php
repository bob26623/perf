<?php
$type='Type1';
$name='MicrosoftSansSerif';
$desc=array('Ascent'=>922,'Descent'=>-210,'CapHeight'=>716,'Flags'=>32,'FontBBox'=>'[-444 -210 957 922]','ItalicAngle'=>0,'StemV'=>70,'MissingWidth'=>293);
$up=-107;
$ut=50;
$cw=array(
	chr(0)=>293,chr(1)=>293,chr(2)=>293,chr(3)=>293,chr(4)=>293,chr(5)=>293,chr(6)=>293,chr(7)=>293,chr(8)=>293,chr(9)=>293,chr(10)=>293,chr(11)=>293,chr(12)=>293,chr(13)=>293,chr(14)=>293,chr(15)=>293,chr(16)=>293,chr(17)=>293,chr(18)=>293,chr(19)=>293,chr(20)=>293,chr(21)=>293,
	chr(22)=>293,chr(23)=>293,chr(24)=>293,chr(25)=>293,chr(26)=>293,chr(27)=>293,chr(28)=>293,chr(29)=>293,chr(30)=>293,chr(31)=>293,' '=>266,'!'=>278,'"'=>355,'#'=>556,'$'=>556,'%'=>889,'&'=>667,'\''=>191,'('=>333,')'=>333,'*'=>389,'+'=>584,
	','=>278,'-'=>333,'.'=>278,'/'=>278,'0'=>556,'1'=>556,'2'=>556,'3'=>556,'4'=>556,'5'=>556,'6'=>556,'7'=>556,'8'=>556,'9'=>556,':'=>278,';'=>278,'<'=>584,'='=>584,'>'=>584,'?'=>556,'@'=>1015,'A'=>667,
	'B'=>667,'C'=>722,'D'=>722,'E'=>667,'F'=>611,'G'=>778,'H'=>722,'I'=>278,'J'=>500,'K'=>667,'L'=>556,'M'=>833,'N'=>722,'O'=>778,'P'=>667,'Q'=>778,'R'=>722,'S'=>667,'T'=>611,'U'=>722,'V'=>667,'W'=>944,
	'X'=>667,'Y'=>667,'Z'=>611,'['=>278,'\\'=>278,']'=>278,'^'=>469,'_'=>552,'`'=>333,'a'=>556,'b'=>556,'c'=>500,'d'=>556,'e'=>556,'f'=>278,'g'=>556,'h'=>556,'i'=>228,'j'=>228,'k'=>500,'l'=>228,'m'=>833,
	'n'=>556,'o'=>556,'p'=>556,'q'=>556,'r'=>333,'s'=>500,'t'=>278,'u'=>556,'v'=>500,'w'=>722,'x'=>500,'y'=>500,'z'=>500,'{'=>334,'|'=>260,'}'=>334,'~'=>584,chr(127)=>293,chr(128)=>293,chr(129)=>293,chr(130)=>293,chr(131)=>293,
	chr(132)=>293,chr(133)=>293,chr(134)=>293,chr(135)=>293,chr(136)=>293,chr(137)=>293,chr(138)=>293,chr(139)=>293,chr(140)=>293,chr(141)=>293,chr(142)=>293,chr(143)=>293,chr(144)=>293,chr(145)=>293,chr(146)=>293,chr(147)=>293,chr(148)=>293,chr(149)=>293,chr(150)=>293,chr(151)=>293,chr(152)=>293,chr(153)=>293,
	chr(154)=>293,chr(155)=>293,chr(156)=>293,chr(157)=>293,chr(158)=>293,chr(159)=>293,chr(160)=>266,chr(161)=>546,chr(162)=>562,chr(163)=>584,chr(164)=>562,chr(165)=>562,chr(166)=>670,chr(167)=>424,chr(168)=>484,chr(169)=>640,chr(170)=>562,chr(171)=>584,chr(172)=>720,chr(173)=>720,chr(174)=>584,chr(175)=>584,
	chr(176)=>484,chr(177)=>680,chr(178)=>766,chr(179)=>776,chr(180)=>562,chr(181)=>562,chr(182)=>546,chr(183)=>575,chr(184)=>502,chr(185)=>620,chr(186)=>584,chr(187)=>584,chr(188)=>562,chr(189)=>562,chr(190)=>652,chr(191)=>652,chr(192)=>584,chr(193)=>584,chr(194)=>500,chr(195)=>484,chr(196)=>546,chr(197)=>484,
	chr(198)=>584,chr(199)=>484,chr(200)=>562,chr(201)=>634,chr(202)=>524,chr(203)=>607,chr(204)=>652,chr(205)=>524,chr(206)=>546,chr(207)=>500,chr(208)=>450,chr(209)=>0,chr(210)=>420,chr(211)=>420,chr(212)=>0,chr(213)=>0,chr(214)=>0,chr(215)=>0,chr(216)=>0,chr(217)=>0,chr(218)=>0,chr(219)=>293,
	chr(220)=>293,chr(221)=>293,chr(222)=>293,chr(223)=>624,chr(224)=>285,chr(225)=>570,chr(226)=>420,chr(227)=>420,chr(228)=>484,chr(229)=>420,chr(230)=>564,chr(231)=>0,chr(232)=>0,chr(233)=>0,chr(234)=>0,chr(235)=>0,chr(236)=>0,chr(237)=>0,chr(238)=>0,chr(239)=>524,chr(240)=>592,chr(241)=>592,
	chr(242)=>624,chr(243)=>624,chr(244)=>624,chr(245)=>624,chr(246)=>592,chr(247)=>624,chr(248)=>624,chr(249)=>624,chr(250)=>644,chr(251)=>852,chr(252)=>293,chr(253)=>293,chr(254)=>293,chr(255)=>293);
$enc='iso-8859-11';
$diff='128 /.notdef 130 /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef 142 /.notdef 145 /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef 158 /.notdef /.notdef 161 /kokaithai /khokhaithai /khokhuatthai /khokhwaithai /khokhonthai /khorakhangthai /ngonguthai /chochanthai /chochingthai /chochangthai /sosothai /chochoethai /yoyingthai /dochadathai /topatakthai /thothanthai /thonangmonthothai /thophuthaothai /nonenthai /dodekthai /totaothai /thothungthai /thothahanthai /thothongthai /nonuthai /bobaimaithai /poplathai /phophungthai /fofathai /phophanthai /fofanthai /phosamphaothai /momathai /yoyakthai /roruathai /ruthai /lolingthai /luthai /wowaenthai /sosalathai /sorusithai /sosuathai /hohipthai /lochulathai /oangthai /honokhukthai /paiyannoithai /saraathai /maihanakatthai /saraaathai /saraamthai /saraithai /saraiithai /sarauethai /saraueethai /sarauthai /sarauuthai /phinthuthai /.notdef /.notdef /.notdef /.notdef /bahtthai /saraethai /saraaethai /saraothai /saraaimaimuanthai /saraaimaimalaithai /lakkhangyaothai /maiyamokthai /maitaikhuthai /maiekthai /maithothai /maitrithai /maichattawathai /thanthakhatthai /nikhahitthai /yamakkanthai /fongmanthai /zerothai /onethai /twothai /threethai /fourthai /fivethai /sixthai /seventhai /eightthai /ninethai /angkhankhuthai /khomutthai /.notdef /.notdef /.notdef /.notdef';
$file='micross.z';
$size1=6107;
$size2=28619;
?>
