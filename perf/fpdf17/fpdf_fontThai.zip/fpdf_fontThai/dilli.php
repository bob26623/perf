<?php
$type='Type1';
$name='DilleniaUPCItalic';
$desc=array('Ascent'=>471,'Descent'=>-129,'CapHeight'=>464,'Flags'=>96,'FontBBox'=>'[-290 -252 790 885]','ItalicAngle'=>-10,'StemV'=>70);
$up=-32;
$ut=5;
$cw=array(
	chr(0)=>600,chr(1)=>600,chr(2)=>600,chr(3)=>600,chr(4)=>600,chr(5)=>600,chr(6)=>600,chr(7)=>600,chr(8)=>600,chr(9)=>600,chr(10)=>600,chr(11)=>600,chr(12)=>600,chr(13)=>600,chr(14)=>600,chr(15)=>600,chr(16)=>600,chr(17)=>600,chr(18)=>600,chr(19)=>600,chr(20)=>600,chr(21)=>600,
	chr(22)=>600,chr(23)=>600,chr(24)=>600,chr(25)=>600,chr(26)=>600,chr(27)=>600,chr(28)=>600,chr(29)=>600,chr(30)=>600,chr(31)=>600,' '=>222,'!'=>212,'"'=>248,'#'=>319,'$'=>319,'%'=>497,'&'=>497,'\''=>177,'('=>177,')'=>177,'*'=>283,'+'=>383,
	','=>159,'-'=>212,'.'=>159,'/'=>212,'0'=>310,'1'=>310,'2'=>310,'3'=>310,'4'=>310,'5'=>310,'6'=>310,'7'=>310,'8'=>310,'9'=>310,':'=>159,';'=>159,'<'=>383,'='=>383,'>'=>383,'?'=>283,'@'=>511,'A'=>462,
	'B'=>391,'C'=>427,'D'=>427,'E'=>391,'F'=>355,'G'=>462,'H'=>462,'I'=>177,'J'=>283,'K'=>391,'L'=>355,'M'=>567,'N'=>462,'O'=>462,'P'=>355,'Q'=>462,'R'=>391,'S'=>355,'T'=>391,'U'=>426,'V'=>427,'W'=>568,
	'X'=>427,'Y'=>391,'Z'=>391,'['=>177,'\\'=>212,']'=>177,'^'=>383,'_'=>319,'`'=>177,'a'=>319,'b'=>355,'c'=>319,'d'=>355,'e'=>319,'f'=>177,'g'=>355,'h'=>355,'i'=>177,'j'=>142,'k'=>319,'l'=>142,'m'=>532,
	'n'=>355,'o'=>319,'p'=>355,'q'=>355,'r'=>212,'s'=>283,'t'=>212,'u'=>355,'v'=>319,'w'=>497,'x'=>319,'y'=>319,'z'=>283,'{'=>212,'|'=>142,'}'=>212,'~'=>383,chr(127)=>600,chr(128)=>600,chr(129)=>600,chr(130)=>600,chr(131)=>600,
	chr(132)=>600,chr(133)=>600,chr(134)=>600,chr(135)=>600,chr(136)=>600,chr(137)=>600,chr(138)=>600,chr(139)=>600,chr(140)=>600,chr(141)=>600,chr(142)=>600,chr(143)=>600,chr(144)=>600,chr(145)=>600,chr(146)=>600,chr(147)=>600,chr(148)=>600,chr(149)=>600,chr(150)=>600,chr(151)=>600,chr(152)=>600,chr(153)=>600,
	chr(154)=>600,chr(155)=>600,chr(156)=>600,chr(157)=>600,chr(158)=>600,chr(159)=>600,chr(160)=>222,chr(161)=>370,chr(162)=>332,chr(163)=>348,chr(164)=>391,chr(165)=>391,chr(166)=>421,chr(167)=>276,chr(168)=>337,chr(169)=>391,chr(170)=>332,chr(171)=>348,chr(172)=>522,chr(173)=>522,chr(174)=>391,chr(175)=>391,
	chr(176)=>323,chr(177)=>451,chr(178)=>526,chr(179)=>522,chr(180)=>391,chr(181)=>387,chr(182)=>370,chr(183)=>387,chr(184)=>327,chr(185)=>391,chr(186)=>387,chr(187)=>387,chr(188)=>397,chr(189)=>397,chr(190)=>427,chr(191)=>427,chr(192)=>391,chr(193)=>391,chr(194)=>370,chr(195)=>296,chr(196)=>370,chr(197)=>362,
	chr(198)=>391,chr(199)=>313,chr(200)=>391,chr(201)=>401,chr(202)=>362,chr(203)=>387,chr(204)=>427,chr(205)=>352,chr(206)=>352,chr(207)=>348,chr(208)=>296,chr(209)=>0,chr(210)=>248,chr(211)=>248,chr(212)=>0,chr(213)=>0,chr(214)=>0,chr(215)=>0,chr(216)=>0,chr(217)=>0,chr(218)=>0,chr(219)=>600,
	chr(220)=>600,chr(221)=>600,chr(222)=>600,chr(223)=>408,chr(224)=>174,chr(225)=>348,chr(226)=>213,chr(227)=>242,chr(228)=>242,chr(229)=>248,chr(230)=>383,chr(231)=>0,chr(232)=>0,chr(233)=>0,chr(234)=>0,chr(235)=>0,chr(236)=>0,chr(237)=>0,chr(238)=>0,chr(239)=>279,chr(240)=>387,chr(241)=>391,
	chr(242)=>462,chr(243)=>437,chr(244)=>407,chr(245)=>397,chr(246)=>370,chr(247)=>475,chr(248)=>437,chr(249)=>411,chr(250)=>384,chr(251)=>799,chr(252)=>600,chr(253)=>600,chr(254)=>600,chr(255)=>600);
$enc='iso-8859-11';
$diff='128 /.notdef 130 /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef 142 /.notdef 145 /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef 158 /.notdef /.notdef 161 /kokaithai /khokhaithai /khokhuatthai /khokhwaithai /khokhonthai /khorakhangthai /ngonguthai /chochanthai /chochingthai /chochangthai /sosothai /chochoethai /yoyingthai /dochadathai /topatakthai /thothanthai /thonangmonthothai /thophuthaothai /nonenthai /dodekthai /totaothai /thothungthai /thothahanthai /thothongthai /nonuthai /bobaimaithai /poplathai /phophungthai /fofathai /phophanthai /fofanthai /phosamphaothai /momathai /yoyakthai /roruathai /ruthai /lolingthai /luthai /wowaenthai /sosalathai /sorusithai /sosuathai /hohipthai /lochulathai /oangthai /honokhukthai /paiyannoithai /saraathai /maihanakatthai /saraaathai /saraamthai /saraithai /saraiithai /sarauethai /saraueethai /sarauthai /sarauuthai /phinthuthai /.notdef /.notdef /.notdef /.notdef /bahtthai /saraethai /saraaethai /saraothai /saraaimaimuanthai /saraaimaimalaithai /lakkhangyaothai /maiyamokthai /maitaikhuthai /maiekthai /maithothai /maitrithai /maichattawathai /thanthakhatthai /nikhahitthai /yamakkanthai /fongmanthai /zerothai /onethai /twothai /threethai /fourthai /fivethai /sixthai /seventhai /eightthai /ninethai /angkhankhuthai /khomutthai /.notdef /.notdef /.notdef /.notdef';
$file='dilli.z';
$size1=5681;
$size2=32322;
?>
